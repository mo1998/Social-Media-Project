<?php
header("location: ../Dark/Login and register/login.php");
?>